//use std::env;
//use std::fs;
//
//fn main() {
//    //read the argumento passwed to the program
//    let args: Vec<String>= env::args().collect();
//    let (file: &str, message: &str) = parse_config(&args)
//
//    
//
//    
//    write(&arg1);
//    println!("arg1: {}",arg1);
//}
//
//struct Note {
//    file: String,
//    message: String, 
//}
//
//fn parse_config(args: $[String]) -> Note{
//    
//    let file:&String = &args[1];
//    let message:&String = &args[2];
//
//    Note {file, message}
//
//}
